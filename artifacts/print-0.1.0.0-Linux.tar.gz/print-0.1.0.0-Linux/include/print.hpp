#include <string>
#include <fstream>
#include <iostream>
///first printf construction
void print(const std::string& text, std::ostream& out = std::cout);
///second print construction
void print(const std::string& text, std::ofstream& out);
